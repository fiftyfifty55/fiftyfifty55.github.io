// products-data.js
// 三個主題名稱順序固定：生活用品 / 玩具 / 服飾
const THEMES = ["生活用品", "玩具", "服飾"];

// PRODUCTS 裡頭只放幾筆示範，請依主題各補 9–10 筆
const PRODUCTS = [
  // ===== 生活用品 =====
  {
    id: "L001",
    theme: "生活用品",
    name: "除臭貓砂盆墊",
    price: 399,
    boughtCount: 120,
    rating: 5.0,
    reviewCount: 18,
    images: ["l001-1.jpg", "l001-2.jpg"], // 你們的圖檔路徑
    variantType: "size",                 // 圖1：尺寸
    sizes: ["S","M","L"],
    stockBySize: { S: 10, M: 6, L: 0 },
    description: "商品介紹…",
    specs: "詳細規格…",
    howToUse: "玩法/用法…"
  },

  // ===== 玩具 =====
  {
    id: "T001",
    theme: "玩具",
    name: "逗貓羽毛棒",
    price: 199,
    boughtCount: 88,
    rating: 4.8,
    reviewCount: 40,
    images: ["t001-1.jpg","t001-2.jpg","t001-3.jpg"],
    variantType: "color",                // 圖2：顏色
    colors: [
      { code: "beige", label: "米色", hex: "#d5bfb4", stock: 12 },
      { code: "taupe", label: "奶茶", hex: "#c9b2a7", stock: 3 },
      { code: "pink",  label: "淡粉", hex: "#ecd9d5", stock: 0 }
    ],
    description: "商品介紹…",
    specs: "詳細規格…",
    howToUse: "玩法/用法…"
  },

  // ===== 服飾 =====
  {
    id: "C001",
    theme: "服飾",
    name: "貓咪小背心",
    price: 259,
    boughtCount: 35,
    rating: 4.9,
    reviewCount: 9,
    images: ["c001-1.jpg"],
    variantType: "size",
    sizes: ["S","M","L"],
    stockBySize: { S: 5, M: 2, L: 1 },
    description: "商品介紹…",
    specs: "詳細規格…",
    howToUse: "玩法/用法…"
  }
];
